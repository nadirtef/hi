<?php

if (!defined('FERNICO')) {
    fernico_destroy();
}

require_once("class.phpmailer.php");
require_once("class.smtp.php");