<?php

if (!defined('FERNICO')) {
    fernico_destroy();
}