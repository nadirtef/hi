<?php

define("FERNICO",true);

require('lib/Astrid/init.php');
new fernico();