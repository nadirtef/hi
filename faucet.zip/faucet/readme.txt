1. Use your FTP/SFTP/WinSCP programme to connect your server or hosting company's server.
2. Navigate to your web root directory, usually public_html, /var/www, etc.
3. Upload the contents of the 'src' folder there.
4. Open the following URL: http://yourwebsite.com/Installer/index.php
5. Fill in the appropriate details - also, make sure that you create the database and paste the valid configuration credentials.
6. Login at http://yourwebsite.com/admin with the administration login credentials you chose.
7. Configure your website and fill in details from FaucetPay.io.